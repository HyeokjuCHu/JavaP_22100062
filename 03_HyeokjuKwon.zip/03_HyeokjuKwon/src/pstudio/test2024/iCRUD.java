package pstudio.test2024;

public interface iCRUD {
    public Object createItem();
    public int addItem();
    public int updateItem();
    public int deleteItem();
    public int printItem();

}
